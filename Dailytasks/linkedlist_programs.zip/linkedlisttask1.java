package org1;
import java.util.LinkedList;
import java.util.Iterator;
public class linkedlisttask1 {
	public static void main(String args[]) {
		LinkedList<String> l=new LinkedList<String>();
		l.add("blue");
		l.addFirst("green");
		l.add("purple");
		l.addLast("gold");
		l.add("silver");
		System.out.println("linked list : "+l);
		System.out.println("============================================");
		 for (String element : l) {
			    System.out.println(element);
			    }
		 System.out.println("============================================");
		 Iterator itr=l.iterator();
		 if(itr.hasNext()) {
			 for(String ele:l) {
				 System.out.println(itr.next());
			 }
			 
		 }
		 System.out.println("============================================");
		 Iterator itr1=l.descendingIterator();
         System.out.println("elements in reverse order");	
         while(itr1.hasNext()) {
        	 System.out.println(itr1.next());
         }
         System.out.println("============================================");
         l.add(1,"yellow");
         System.out.println("After inserting the value at spesified location :"+l);
         System.out.println("============================================");
         l.addFirst("biscuit");
         l.addLast("chocolate");
         System.out.println("After inserting the elements at first and last positions of linked list :"+l);
         System.out.println("============================================");
         l.add(0,"orange");
         System.out.println("after inserting specified value at first position of linked list :"+l);
         System.out.println("============================================");
         l.addLast("Techm");
         System.out.println("After inserting specified value at end of the linked list :"+l);
         System.out.println("============================================");
        System.out.println("The first element of linked list is :"+l.getFirst()+" And the last element of the linked list is :"+l.getLast());
	}

}
