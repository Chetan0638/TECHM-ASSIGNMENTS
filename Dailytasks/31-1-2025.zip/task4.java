package org;
import java.util.Arrays;
public class task4 {
	public static void main(String args[]) {
		int arr1[] = {10,20,30,40,50};
		int arr2[] = Arrays.copyOfRange(arr1, 1, 4);
		System.out.println("copied range of elements "+ Arrays.toString(arr2));
				}
		
	}


