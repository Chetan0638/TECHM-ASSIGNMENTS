package org;
import java.util.Scanner;
public class task12 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n;
		int res=0;
		
		n=sc.nextInt();
		while(n!=0) {
			int rem=n%10;
			res=res*10+rem;
			n=n/10;
			
		}
		System.out.println(res);
	}

}
