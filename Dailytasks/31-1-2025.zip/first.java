package org;
import java.util.Scanner;
public class first {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int num1,num2,res;
		num1=scan.nextInt();
		num2=scan.nextInt();
		res=num1+num2;
		System.out.println(res);
	}

}
