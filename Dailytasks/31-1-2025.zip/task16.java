package org;
import java.util.Scanner;
public class task16 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		StringBuffer sb=new StringBuffer(sc.next().toLowerCase());
		sb.reverse();
		System.out.print("after string reverse "+sb);
		
	}

}
