
package org;

import java.util.Arrays;

public class task3 {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40};
        int[] arr1 = {10, 20, 30, 40};
        System.out.println("a1 equals to a2: " + Arrays.equals(arr, arr1));
    }
}

