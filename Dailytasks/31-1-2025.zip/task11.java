package org;

import java.util.Arrays;
import java.util.Scanner;

public class task11 {
    static class Medicine {
        private String medicineName;
        private String batch;
        private String disease;
        private int price;

        public Medicine(String medicineName, String batch, String disease, int price) {
            this.medicineName = medicineName;
            this.batch = batch;
            this.disease = disease;
            this.price = price;
        }

        // Getters and Setters
        public String getMedicineName() {
            return medicineName;
        }

        public void setMedicineName(String medicineName) {
            this.medicineName = medicineName;
        }

        public String getBatch() {
            return batch;
        }

        public void setBatch(String batch) {
            this.batch = batch;
        }

        public String getDisease() {
            return disease;
        }

        public void setDisease(String disease) {
            this.disease = disease;
        }

        public int getPrice() {
            return price;
        }

        public void setPrice(int price) {
            this.price = price;
        }
    }

    public static Integer[] getPriceByDisease(Medicine[] medicines, String disease) {
        Integer[] prices = Arrays.stream(medicines)
                .filter(medicine -> medicine.getDisease().equalsIgnoreCase(disease))
                .map(Medicine::getPrice)
                .toArray(Integer[]::new);
        Arrays.sort(prices);
        return prices;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Medicine[] medicines = new Medicine[4];
        for (int i = 0; i < 4; i++) {
            String medicineName = scanner.next();
            String batch = scanner.next();
            String disease = scanner.next();
            int price = scanner.nextInt();

            medicines[i] = new Medicine(medicineName, batch, disease, price);
        }

        String disease = scanner.next();

        Integer[] prices = getPriceByDisease(medicines, disease);
        if (prices.length > 0) {
            System.out.println(prices[0]);
        } else {
            System.out.println("No medicine found for the given disease");
        }
    }
}

