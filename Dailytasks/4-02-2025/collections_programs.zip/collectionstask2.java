package org1;
import java.util.List;
import java.util.ArrayList;
public class collectionstask2 {
	  public static void main(String[] args) {
	  List<String> list_Strings = new ArrayList<String>();
	  list_Strings.add("yellow");
	  list_Strings.add("red");
	  list_Strings.add("green");
	  list_Strings.add("brown");
	  list_Strings.add("Black");
	  // Print the list
	  for (String element : list_Strings) {
	    System.out.println(element);
	    }
	 }
	}


