package org1;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public class collectiontask4 {
	public static void main(String[] args) {
		  List<String> list_Strings = new ArrayList<String>();
		  list_Strings.add("Red");
		  list_Strings.add("Green");
		  list_Strings.add("Orange");
		  list_Strings.add("White");
		  list_Strings.add("Black");
		  List<String> list1=new ArrayList<String>();
		  list1.add("monday");
		  list1.add("tuesday");
		  list1.add("wednesday");
		  list1.add("thursday");
		  System.out.println(list_Strings);
		  String element = list_Strings.get(3);
		  System.out.println("First element: "+element);
		  element = list_Strings.get(4);
		  System.out.println("Third element: "+element);
		  System.out.println("==============================================");
		  element=list_Strings.set(1,"pink");
		  System.out.println(list_Strings);
		  System.out.println("==============================================");
		  element=list_Strings.remove(1);
		  System.out.println("After removing "+list_Strings);
		  System.out.println("==============================================");
		  if(list_Strings.contains("White")) {
			  System.out.println("found the element in arraylist");
		  }
		  else{
			  System.out.println("element not found");
		  }
		  System.out.println("==============================================");
		  Collections.sort(list_Strings);
		  System.out.println("The above list is sorted alphabetically "+list_Strings);
		  System.out.println("==============================================");
		  Collections.copy(list_Strings,list1);
		  System.out.println("Copy List1 to List2,\nAfter copy:");
		  System.out.println("List1: " + list_Strings);
		  System.out.println("List2: " + list1);
		  System.out.println("==============================================");
		  System.out.println("List before shuffling:\n" + list_Strings);  
		  Collections.shuffle(list_Strings);
		  System.out.println("List after shuffling:\n" + list_Strings);
		  System.out.println("==============================================");
		  
		  
		 }
		}

