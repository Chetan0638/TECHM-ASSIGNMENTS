package org1;
import java.util.List;
import java.util.ArrayList;
public class collectionstask3 {
	public static void main(String args[]) {
		  List<String> list_Strings = new ArrayList<String>();
		  list_Strings.add("orange");
		  list_Strings.add("Green");
		  list_Strings.add("yellow");
		  list_Strings.add("pink");
		  list_Strings.add("Black");
		  System.out.println(list_Strings);
		  list_Strings.add(0, "Pink");
		  list_Strings.add(5, "Yellow");
		  System.out.println(list_Strings);
		 }
}
