package org1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class collectionstask1 {
	 public static void main(String[] args) {
		  ArrayList a1=new ArrayList();
		 a1.add("yellow");
		 a1.add("red");
		 a1.add("green");
		 a1.add("brown");
		 a1.add("black");
		 Iterator itr=a1.iterator();
		 while(itr.hasNext()) {
			 Object ele=itr.next();
			 System.out.println(ele);
		 }
		 }
}
