package org1;
import java.util.ArrayList;
import java.util.List;
public class generictask4 {
	public static <T> List <T> reverse(List <T> list) {
		 List < T > reversedList = new ArrayList < > ();
		 for (int i = list.size() - 1; i >= 0; i--) {
			 reversedList.add(list.get(i));
		}
		return reversedList;
	}
	public static void main(String args[]) {
		List <Integer> numbers=List.of(1,2,3,4,5,6);
		List < Integer > reversedNumbers = reverse(numbers);
    	System.out.println("Nums:"+numbers);
    	System.out.println("reversedlist= "+reversedNumbers);
	}

}
