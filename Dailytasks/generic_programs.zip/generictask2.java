package org1;
import java.util.Scanner;
public class generictask2 {
 public static  <T extends Number>   void sum(T[] numbers){
	int evensum=0;
	int oddsum=0;
	 for (T number:numbers) {
		 if(number.intValue()%2==0) {
			 evensum+=number.intValue();
;		 }
		 else {
			 oddsum+=number.intValue();
			 
		 }
		 
		 
	 }
	 System.out.println("sum of even numbers:"+evensum);
	 System.out.println("sum of oddnumbers:" +oddsum);
	
	 
 }
 public static void main(String args[] ){
	Integer num[]= {1,2,3,4,5};
	 sum(num);
 
 }
}
