package org1;
import java.util.Arrays;
public class generic1 {
	public static < T > String arrays(T[] arr1,T[] arr2) {
		if(arr1.length!=arr2.length) {
			 return "both arrays are not equal";
		}
		for(int i=0;i<arr1.length;i++) {
			if(!arr1[i].equals(arr2[i])) {
				return "both array elements are not in same order";
			}
			else {
				return "both array elements are equal";
				
			}
		}
		return null;
	}
public static void main(String args[]) {
	Integer[] arr1= {
			1,2,3,4
	};
	Integer[] arr2= {
			1,2,3,4
	};
	System.out.println("compare arr1 and arr2 "+arrays(arr1,arr2));
}
}
