package org1;
import java.util.List;
public class generictask3 {
	public static <T> int findtarget(List <T> list,T target) {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).equals(target)) {
				return i;
			}
		}
		return -1;
	}
    public static void main(String args[]) {
    	List <Integer> numbers=List.of(1,2,3,4,5,6);
    	System.out.println("Nums:"+numbers);
    	int index=findtarget(numbers,1);
    	System.out.println("index 3 in numbers" + index);
    	int index1=findtarget(numbers,10);
    	System.out.println("index 10 in numbers" + index1);
    }
}
