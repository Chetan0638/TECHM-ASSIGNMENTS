package org;
import java.io.File;
public class iostreamstask3 {
	public static void main(String args[]){
		File directory=new File("C:\\Users\\krish\\OneDrive\\Desktop\\task2.zip");
		if (directory.exists()) {
			System.out.println("yes the file exists");
		}
		else {
			System.out.println("no such file exists");
		}
		
	}

}
