package org;
import java.io.File;
public class iostreamstask4 {
	public static void main(String args[]) {
		File permissions=new File("C:\\Users\\krish\\OneDrive\\Desktop\\task2.zip");
		if(permissions.canRead()) {
			System.out.println("the file"+permissions.getAbsolutePath()+" can write");
		}
		else {
			System.out.println("the file"+permissions.getAbsolutePath()+" cannot write");
		}
		if(permissions.canRead()) {
			System.out.println("the file"+permissions.getAbsolutePath()+" can read");
			
		}
		else {
			System.out.println("the file"+permissions.getAbsolutePath()+" cannot read");
		}
	}

}
