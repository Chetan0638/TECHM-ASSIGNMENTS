package org;
import java.io.File;
public class iostreamstask1 {
      public static void main(String args[]) {
    	  File file=new File("C:\\Users\\krish\\OneDrive\\Desktop\\techm_questions and notes");
    			  String[] filelist=file.list();
    			  for(String name:filelist) {
    				  System.out.println(name);
    				  
    			  }
      }
}
