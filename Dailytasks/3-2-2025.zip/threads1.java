package org;

public class threads1 extends Thread {
	public void run() {
		System.out.println("hello java");
	}
public static void main(String args[]) {
	threads1 thread=new threads1();
	thread.start();
	
}
}
