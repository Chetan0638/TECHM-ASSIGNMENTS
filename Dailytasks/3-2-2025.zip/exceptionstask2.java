package org;
import java.util.Scanner;
class OddNumberException extends Exception {
    public OddNumberException(String message) {
        super(message);
    }
}
public class exceptionstask2 {
    static void checkOdd(int num) throws OddNumberException {
        if (num % 2 != 0) {
            
			throw new OddNumberException("The  number is odd.");
        } else {
            System.err.println( "The number is even.");
        }
    }

    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	int n=sc.nextInt();
    	
        try {
        	checkOdd(n);
       
            
        } catch (OddNumberException e) {
            System.out.println(e.getMessage());
        }
    }
}
