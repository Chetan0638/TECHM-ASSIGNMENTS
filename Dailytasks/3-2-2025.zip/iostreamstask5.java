package org;
import java.io.File;
public class iostreamstask5 {
	public static void main(String args[]) {
		File f=new File("C:\\Users\\krish\\OneDrive\\Desktop\\task2.zip");
		if(f.isDirectory()) {
			System.out.println("the file "+f.getAbsolutePath()+"is a directory");
		}
		else {
			System.out.println("the file "+f.getAbsolutePath()+"is a file");
			
		}
	}

}
