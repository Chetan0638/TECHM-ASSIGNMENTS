package org;
import java.io.File;
public class iostreamtask8 {
	public static void main(String args[]) {
		File file=new File("C:\\Users\\krish\\OneDrive\\Documents\\musify application");
		if(file.exists()) {
			System.out.println(Bytes(file));
	        System.out.println(kb(file));
	        System.out.println(mb(file));
	        }
	        else 
	        System.out.println("File doesn't exist");    
	    }
	    private static String mb(File file) {
	        return (double) file.length()/(1024*1024)+" mb";
	    }
	    private static String kb(File file) {
	        return (double) file.length()/1024+"  kb";
	    }
	    private static String Bytes(File file) {
	        return file.length()+" bytes";
	    }
	 }