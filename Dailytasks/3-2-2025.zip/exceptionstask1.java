package org;
import java.io.*;
import java.util.Scanner;
public class exceptionstask1 {
	public static void main(String args[]) {
		int n,m,res = 0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		m=sc.nextInt();
		try {
			res=n/m;
			
		}
		catch (ArithmeticException e ) {
			//System.err.println("cannot divide a number by zero");
			e.printStackTrace();
		}
		
		
	}

}
