package org;
import java.util.Scanner;

class iostreamstask7 {
    public static void main(String args[])
    {
        Scanner s = new Scanner(System.in);
        String s1 = s.nextLine();
        System.out.println("You entered string " + s1);
    }
}

