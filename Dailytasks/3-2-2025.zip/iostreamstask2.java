package org;
import java.io.File;
import java.io.FilenameFilter;
public class iostreamstask2 {
       public static void main(String a[]){
        File file = new File("C:\\Users\\krish\\OneDrive\\Desktop");
           String[] list = file.list(new FilenameFilter() {
            public boolean accept(File dir, String name) {
             if(name.endsWith(".pdf")){
                    return true;
                } else {
                    return false;
                }
            }
        });
        for(String f:list){
            System.out.println(f);
        }
    }
}
