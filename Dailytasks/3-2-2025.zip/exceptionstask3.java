package org;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
public class exceptionstask3 {
	public static void main(String args[]) {
		try {
			readFile("file.txt");
		}
		catch(FileNotFoundException e) {
			System.err.println("Error: " + e.getMessage());
			
		}
	}
public static void readFile(String filename)throws FileNotFoundException{
	File f=new File(filename);
	Scanner sc=new Scanner(f);
	while (sc.hasNextLine()) {
		String line=sc.nextLine();
		System.out.println(line);
	}
	
}
}
