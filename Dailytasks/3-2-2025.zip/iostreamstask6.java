package org;
import java.io.File;
public class iostreamstask6 {
	public static void main(String args[]) {
		File f=new File("C:\\Users\\krish\\OneDrive\\Desktop\\task2.zip");
		System.out.println(f.lastModified());	
			
		}
	}


